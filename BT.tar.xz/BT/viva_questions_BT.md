Here is a mix of super surface-level "easy mark" questions and standard SPPU BE CS external viva questions tailored directly to your LP-III Blockchain lab manual and your `StudentData.sol` writeup.

---

### Part 1: Surface-Level / "Warm-up" Questions

*(Examiners usually ask these first just to check if you actually opened the browser/IDE and read the title of your own practical.)*

**1. What is the full form of DApp, EVM, and BNA?**

* **DApp:** Decentralized Application.


* **EVM:** Ethereum Virtual Machine.


* **BNA:** Business Network Archive (used in Hyperledger Composer).



**2. What is the logo of MetaMask, and what kind of software is it?**

* It is a **fox** logo. MetaMask is a non-custodial **hot wallet** and browser extension (available on Chrome, Firefox, Brave, Opera) that injects the Web3 API into websites so DApps can interact with the Ethereum blockchain.



**3. How many words are in a MetaMask Secret Backup (Seed) Phrase, and why shouldn't you store it in a text file?**

* **12 words**. Anyone with those 12 words can regenerate your private keys and steal your funds permanently, so storing it digitally exposes it to malware/hacks.



**4. What is the difference between a Hot Wallet and a Cold Wallet?**

* **Hot Wallet:** Connected to the internet (e.g., MetaMask, exchange wallets)—convenient for frequent DApp interactions but more exposed to online attacks.


* **Cold Wallet:** Offline hardware/physical device (e.g., Ledger, Trezor) storing private keys completely offline for maximum security.



**5. Which programming language did you use for Ethereum smart contracts, and what file extension does it use?**

* **Solidity**, with the `.sol` extension.



**6. What is the difference between Bitcoin and Ether (ETH)?**

* **Bitcoin** (2009, Satoshi Nakamoto) was designed primarily as a peer-to-peer digital currency/store of value. **Ethereum** (2015) is a programmable blockchain platform that runs Smart Contracts, and **Ether (ETH)** is its native cryptocurrency used to pay for computation (gas) and transfers.



**7. Name the 4 types of Blockchains.**

* **Public** (permissionless, e.g., Bitcoin, Ethereum), **Private** (single organization, e.g., Hyperledger Fabric, Corda), **Consortium/Federated** (controlled by a group of organizations, e.g., Tendermint, Multichain), and **Hybrid** (mix of public and private access, e.g., Ripple/XRP).



**8. In your Student Data contract, what happens if you click a blue button vs. an orange button in Remix IDE?**

* **Blue buttons** (`view` functions like `displayAllStudents`, `getLengthOfStudents`) only read blockchain state and cost **0 gas**.


* **Orange buttons** (state-modifying functions like `addStudent`) write to blockchain storage and require a transaction with **gas fees**.



---

### Part 2: Standard SPPU BE CS Final Year Viva Questions

#### Assignment 1 & 2: MetaMask & Ether Transactions

**1. Does MetaMask download the entire Ethereum blockchain onto your laptop?**

* **No.** MetaMask acts as a light client/interface. It manages your keys locally and sends RPC requests to remote Ethereum nodes (like Infura) so you don't have to download hundreds of gigabytes of ledger data.



**2. What is "Double Spending" and how does Blockchain prevent it?**

* Double spending is attempting to spend the exact same digital token twice. Blockchain prevents it through cryptographic signatures, chronological linking of blocks via hashes, and distributed **consensus mechanisms** (PoW/PoS) where network nodes verify transaction history before appending a block.



**3. What is a Merkle Tree and why is it used in a block header?**

* A Merkle Tree is a binary hash tree where leaf nodes are hashes of individual transactions and non-leaf nodes are hashes of their concatenated children, culminating in a single **Merkle Root** stored in the block header. It allows efficient, tamper-evident verification of whether a transaction belongs to a block without downloading the entire block.

**4. How is a transaction fee calculated on Ethereum?**

* $\text{Transaction Fee} = \text{Gas Used} \times \text{Gas Price}$ (measured in **Gwei**, where $1\text{ ETH} = 10^9\text{ Gwei}$).



---

#### Assignment 3: Bank Smart Contract (`Bank.sol`)

**5. What is `msg.sender` and `msg.value` in Solidity?**

* `msg.sender` is a global variable representing the address of the account (EOA or another contract) that directly called the current function.


* `msg.value` is the amount of Ether (in **Wei**, where $1\text{ ETH} = 10^{18}\text{ Wei}$) sent along with a `payable` function call.



**6. Why does the `deposit` function need the `payable` keyword, while `withdraw` doesn't?**

* In Solidity, a function cannot receive Ether unless it is explicitly marked `payable` (otherwise the EVM reverts the transaction). `withdraw` sends Ether *out* of the contract to `msg.sender`, so it doesn't receive Ether.



**7. What is a `mapping` in Solidity, and what is the default value of an uninitialized key?**

* `mapping(address => uint256)` is a hash-table-like key-value store in contract storage. Unlike standard hash maps, you cannot iterate over keys, and any key that hasn't been written to automatically returns the default zero-value (`0` for `uint256`).



**8. (Classic External Favorite) In your `Bank` contract's `withdraw()` function, why did you subtract `balanceOf[msg.sender] -= amount` *before* calling `msg.sender.transfer(amount)`?**

* To prevent a **Reentrancy Attack**. If you transfer Ether first and `msg.sender` is a malicious smart contract, its `receive()`/`fallback()` function can recursively call `withdraw()` again before its balance is updated, draining the entire contract. Updating state first follows the **Checks-Effects-Interactions** pattern.



---

#### Your Assignment 4: Student Data Smart Contract (`StudentData.sol`)

**9. What is the difference between `storage` and `memory` in Solidity?**

* **`storage`** is persistent state stored permanently on the blockchain (expensive in gas, e.g., `Student[] public studentArr`).


* **`memory`** is temporary, non-persistent RAM allocated only during function execution (cheaper in gas, e.g., `string memory name` parameter).



**10. What is the difference between `fallback()` and `receive()` in Solidity `^0.8.0`?**

* **`receive() external payable`** is triggered *only* when a contract receives plain Ether with empty `msg.data` (no calldata).


* **`fallback() external payable`** is triggered when a caller invokes a function signature that does not exist in the contract, or sends Ether with non-empty `msg.data` when `receive()` doesn't match.



**11. Why is `Execution Cost` lower than `Transaction Cost` in Remix IDE?**

* **Execution Cost** only counts the gas consumed by executing EVM opcodes inside the smart contract. **Transaction Cost** equals Execution Cost *plus* the base intrinsic gas of sending a transaction on Ethereum (`21,000` gas + gas per byte of `CALLDATA` + contract deployment overhead).



**12. Why did you use a `for` loop in `addStudent` to check duplicate roll numbers, and what is its drawback on-chain?**

* It prevents duplicate `rollno` entries in `studentArr`. However, iterating over an unbounded dynamic array on-chain has $O(n)$ gas complexity—if the array grows too large, the loop will exceed the block gas limit (DoS). A `mapping(uint => bool)` check would be $O(1)$.



---

#### Assignment 5 (Lab Manual): Hyperledger Composer & Fabric

**13. How is Hyperledger Fabric different from Ethereum?**

* Ethereum is a **public, permissionless** blockchain with a native cryptocurrency (ETH) and smart contracts written in Solidity. Hyperledger Fabric is a **private/consortium, permissioned** enterprise blockchain with no native cryptocurrency, modular consensus, strict identity management (MSP/certificates), and smart contracts called **Chaincode**.



**14. What are the 4 core files packaged inside a `.bna` (Business Network Archive) file in Hyperledger Composer?**

1. **Model File (`.cto`):** Defines Assets, Participants, and Transactions.


2. **Script File (`.js`):** Contains JavaScript transaction processor functions.


3. **Access Control File (`permissions.acl`):** Defines role-based access rules.


4. **Query File (`.qry`):** Defines custom queries against the world state.



**15. What is a Business Network Card (`.card`) and what is the Historian Registry?**

* **Business Network Card:** A bundle containing a participant's identity credentials, connection profile (JSON), and metadata used to connect to the Hyperledger Fabric network.


* **Historian Registry:** A built-in system registry that logs an immutable audit trail of every successful transaction submitted to the network along with the identity that invoked it.



---

Want me to drill you on anything specific—like tracing line-by-line bytecode/gas behavior in `StudentData.sol` or handling tricky follow-up questions on `require` vs `revert` vs `assert`?