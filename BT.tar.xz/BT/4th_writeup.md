## Assignment No. 4: Student Data Smart Contract in Solidity

### Title

Write a program in Solidity to create Student data using Structures, Arrays, and Fallback, deploy it as a smart contract on Ethereum, and observe the transaction fee and Gas values.

---

### Objective

* To understand custom user-defined data types (**Structures**) and dynamic collections (**Arrays**) in Solidity.
* To implement the **`fallback`** (and `receive`) special functions to handle unexpected function calls or plain Ether transfers.
* To deploy a smart contract on an Ethereum environment (Remix VM / Testnet) and analyze **Gas consumption** and **transaction fees** for read versus write operations.

---

### Theory

#### 1. Structures (`struct`) in Solidity

A `struct` allows grouping multiple variables of different data types under a single custom type to represent real-world entities (such as a `Student` record containing `name` and `rollno`). Structs are stored in contract `storage` when declared as state variables, or in temporary `memory` inside functions.

#### 2. Arrays in Solidity

Arrays store ordered collections of elements of the same type and can be either fixed-size or dynamic (`Student[] public studentArr;`). Dynamic storage arrays support `.push()` to append new elements and `.length` to query the total number of stored records.

#### 3. Fallback Function (`fallback` & `receive`)

* **`fallback() external payable`:** A special nameless function executed automatically when a contract receives a call whose function signature does not match any declared function in the contract (or when data is sent without a matching selector).
* **`receive() external payable`:** Executed when a contract receives plain Ether with empty `msg.data` (`CALLDATA`).

#### 4. Gas and Transaction Fees on Ethereum

* **Gas:** The unit measuring the computational effort required to execute operations on the Ethereum Virtual Machine (EVM). State-modifying operations (like `SSTORE` when pushing a struct to storage) consume significant gas, whereas read-only `view` calls executed off-chain consume **0 gas**.
* **Gas Price & Transaction Fee:**

$$\text{Transaction Fee} = \text{Gas Used} \times \text{Gas Price}$$



In Remix IDE, **Execution Cost** represents the gas used strictly by EVM opcodes, while **Transaction Cost** includes both execution cost and the base cost of sending transaction data (`21,000` base gas + calldata bytes).

---

### Smart Contract Code (`StudentData.sol`)

```solidity
// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

contract StudentData {
    struct Student {
        string name;
        uint rollno;
    }

    Student[] public studentArr;
    uint public fallbackCount = 0;

    function addStudent(string memory name, uint rollno) public {
        for (uint i = 0; i < studentArr.length; i++) {
            if (studentArr[i].rollno == rollno) {
                revert("Student with roll no already exists!");
            }
        }
        studentArr.push(Student(name, rollno));
    }

    function displayAllStudents() public view returns (Student[] memory) {
        return studentArr;
    }

    function getStudentByIndex(uint index) public view returns (Student memory) {
        require(index < studentArr.length, "Index out of bound");
        return studentArr[index];
    }

    function getLengthOfStudents() public view returns (uint) {
        return studentArr.length;
    }

    fallback() external payable {
        fallbackCount += 1;
    }

    receive() external payable {
        fallbackCount += 1;
    }
}

```

---

### Procedure & Gas Observation

1. **Compile & Deploy:** Open Remix IDE (`[https://remix.ethereum.org](https://remix.ethereum.org)`), create `StudentData.sol`, compile with Solidity `^0.8.0`, and deploy on **Remix VM**.
2. **Add Student Records:** Invoke `addStudent("Shree", 101)` and `addStudent("Amol", 102)`. Observe in the transaction terminal that each write transaction consumes gas (`transaction cost` and `execution cost`) because it modifies blockchain storage.


3. **Query Records:** Invoke `displayAllStudents()`, `getStudentByIndex(0)`, and `getLengthOfStudents()`. Observe that `view` functions execute as local `call`s with **0 external gas cost**.


4. **Trigger Fallback:** Under **Low level interactions**, send arbitrary `CALLDATA` (`0x1234`) and click **Transact**. Verify `fallbackCount` increments to `1`.

| Operation | Type | Modifies State? | Gas Consumed? |
| --- | --- | --- | --- |
| `Deploy` | Contract Creation | Yes | High (bytecode storage) |
| `addStudent(...)` | Write Transaction | Yes | Moderate (`SSTORE` array push) |
| `fallback` (`0x1234`) | Write Transaction | Yes | Low (`fallbackCount` increment) |
| `displayAllStudents()` | `view` Call | No | **0 Gas** (external read call) |
| `getStudentByIndex(0)` | `view` Call | No | **0 Gas** (external read call) |

---

### Conclusion

In this assignment, we designed and deployed a `StudentData` smart contract in Solidity utilizing `struct` for structured student records, dynamic arrays for on-chain storage, and `fallback`/`receive` handlers for unmatched low-level interactions, while observing the difference in gas consumption between state-changing transactions and read-only calls.