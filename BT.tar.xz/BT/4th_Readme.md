### Step-by-Step Instructions for Practical 4 (`StudentData.sol`) in Remix IDE

#### 1. Compile & Deploy

1. Open **`[https://remix.ethereum.org](https://remix.ethereum.org)`** and create `StudentData.sol` with the fixed Solidity `^0.8.0` code (including `fallback()` and `receive()`).
2. Go to the **Solidity Compiler** tab (3rd icon on the left) $\rightarrow$ click **Compile StudentData.sol**.
3. Go to the **Deploy & Run Transactions** tab (4th icon on the left):
* Set **Environment** to **Remix VM (Cancun)** (matching your compiler's EVM version).
* Confirm **Value** is **`0`**.
* Click **Deploy**.


4. Scroll down to **Deployed Contracts** and expand your deployed `STUDENTDATA` contract.

---

#### 2. Test Structures & Arrays (Add & Retrieve Students)

1. **Add First Student:**
* Expand the orange **`addStudent`** function.
* Enter `name`: `"Shree"` and `rollno`: `101`.
* Click **transact** (check the bottom terminal for a green checkmark).


2. **Add Second Student:**
* In `addStudent`, enter `name`: `"Amol"` and `rollno`: `102`.
* Click **transact**.


3. **Verify Array Length:**
* Click the blue **`getLengthOfStudents`** button $\rightarrow$ outputs `2`.


4. **Fetch Single Student (Struct):**
* In the blue **`getStudentByIndex`** input box, enter `0` and click **`getStudentByIndex`** $\rightarrow$ returns `tuple(string,uint256): Shree,101`.


5. **Display Full Array:**
* Click the blue **`displayAllStudents`** button $\rightarrow$ returns `tuple(string,uint256)[]: Shree,101,Amol,102`.



---

#### 3. Test the `fallback` Function

1. Scroll down to the very bottom of your deployed `STUDENTDATA` panel to the **Low level interactions** section.
2. In the **`CALLDATA`** box, enter **`0x1234`** (any non-empty hex bytes that do not match an existing function signature).
3. Click **`Transact`**.
4. Click the blue **`fallbackCount`** button above $\rightarrow$ verify it updates from `0` to **`1`**.

---

#### 4. Observe Transaction Fee & Gas Values (Syllabus Requirement)

1. Look at the bottom terminal log and click the down-arrow (`v`) next to any green checkmark (e.g., `addStudent` or `Deploy`).
2. Point out the gas metrics to the examiner:
* **`gas`:** The gas limit set for the transaction.
* **`transaction cost` & `execution cost`:** Exact gas units consumed by writing data to the blockchain state.
* **Zero Gas on Read Calls:** Click `displayAllStudents` and expand its log (`call`) to show that `view` functions do not broadcast a transaction and consume **0 gas** externally.



---

#### 5. Optional Viva Demo (Duplicate Check & Bounds Check)

* **Duplicate Roll Number:** Try calling `addStudent` with `"Test"`, `101` again $\rightarrow$ reverts with `"Student with roll no already exists!"`.
* **Out-of-Bounds Index:** Try calling `getStudentByIndex` with `5` $\rightarrow$ reverts with `"Index out of bound"`.