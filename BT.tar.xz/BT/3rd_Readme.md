### Step-by-Step Instructions for Practical 3 (`Bank.sol`) in Remix IDE

#### 1. Compile & Deploy

1. Open **`[https://remix.ethereum.org](https://remix.ethereum.org)`** and create `Bank.sol` with the fixed Solidity `^0.8.0` code.
2. Go to the **Solidity Compiler** tab (3rd icon on the left) $\rightarrow$ click **Compile Bank.sol**.
3. Go to the **Deploy & Run Transactions** tab (4th icon on the left):
* Set **Environment** to **Remix VM (Cancun)** (or ensure the VM matches your compiler's EVM version).
* Confirm **Value** is **`0`**.
* Click **Deploy**.


4. Scroll down to **Deployed Contracts** and expand your deployed `BANK` contract.

---

#### 2. Test Deposit Money

1. Scroll up to the **Value** field in the Deploy & Run panel.
2. Enter **`10`** and change the unit dropdown from `Wei` to **`Ether`** (or leave as `Wei` and enter `100`).
3. Go back down to your deployed `BANK` contract and click the red **`Deposit`** button.
4. Check the bottom terminal panel for a green checkmark confirming the deposit transaction succeeded.

---

#### 3. Test Show Balance

1. Click the blue **`showBalance`** button inside your deployed `BANK` contract.
2. Verify the returned balance matches your deposit (`10000000000000000000` if you deposited 10 Ether, or `100` if you deposited 100 Wei).

---

#### 4. Test Withdraw Money

1. First, make sure the top **Value** field is reset to **`0`**.
2. In the orange **`Withdraw`** input box inside your deployed `BANK` contract, enter the amount to withdraw in Wei (e.g., `4000000000000000000` for 4 Ether, or `40` if you deposited 100 Wei).
3. Click **`Withdraw`**.
4. Click **`showBalance`** again to verify the balance decreased properly (`6000000000000000000` or `60`), and notice your selected Account's ETH balance at the top increased back.

---

#### 5. Optional Viva Demo (Owner Check & Insufficient Balance)

* **Show Owner Restriction:** Switch the **Account** dropdown at the top-left from `Account 1` to `Account 2`, then click **`showBalance`** or **`Withdraw`** $\rightarrow$ it reverts with `"You are not an account owner"`.
* **Show Overdraft Protection:** Switch back to `Account 1` and try withdrawing more than your current balance $\rightarrow$ it reverts with `"Account does not have sufficient balance!"`.